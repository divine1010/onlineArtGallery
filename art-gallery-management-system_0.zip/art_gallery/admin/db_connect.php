<?php 

$conn= new mysqli('localhost','root','','art_gallery_db')or die("Could not connect to mysql".mysqli_error($con));
